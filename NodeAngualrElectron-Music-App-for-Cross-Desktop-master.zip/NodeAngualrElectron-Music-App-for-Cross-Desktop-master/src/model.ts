export interface ISong {
  id: number;
  title: string;
  path: string;
}