//All the configurations required like portNumber, Database Connection URl etc are stored to provide a low level encapsulation

module.exports = {
  database:
    'mongodb://ramteja:ramteja@ds241019.mlab.com:41019/ecommerce',
  port: 3030,
  secret: 'RamtejaRepaka2012312321'
};

