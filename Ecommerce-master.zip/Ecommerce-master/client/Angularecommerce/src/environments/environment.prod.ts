export const environment = {
  production: true,
  stripeKey: 'pk_test_DVAYtghfj48mnkPlrOV4YD0E'
};
