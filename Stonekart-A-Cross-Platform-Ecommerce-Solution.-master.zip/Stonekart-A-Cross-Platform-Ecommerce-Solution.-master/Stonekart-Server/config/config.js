module.exports = {

    database: 'mongodb://localhost:27017/ionicdb',
    secret: 'stonekart_secret',
 
    // Your Twilio account SID and auth token, both found at: https://www.twilio.com/user/account
    accountSid : 'AC11793ce8ef22ded9a6d82d23a0537806',  
    authToken :  'e612d682dd3aa27bf74536bdb633ddd7',
    // A Twilio number you control Specify, e.g. "+16519998877"
    twilioNumber : '+441224515461',
    // Your Authy production key
    authyKey : 'j9JxCNgzlnvcAwj8e9GehnKctDLtnJ1i',
    // Enable SMS 2FA processes
    enableValidationSMS : 1
}