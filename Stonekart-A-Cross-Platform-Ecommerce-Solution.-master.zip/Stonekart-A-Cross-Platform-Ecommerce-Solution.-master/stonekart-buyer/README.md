Stonekart-buyer

Install Node JS Software

Go to terminal or command line.

Execute following commands to run this application.


```
$ git clone https://github.com/srinivastamada/ionic-welcome.git
$ cd ionic-welcome
$ npm install
$ ionic serve

```

ios
```
$ cordova add platform ios

$ ionic build ios

```

Android
```
$ cordova add platform android

$ ionic build android

```
