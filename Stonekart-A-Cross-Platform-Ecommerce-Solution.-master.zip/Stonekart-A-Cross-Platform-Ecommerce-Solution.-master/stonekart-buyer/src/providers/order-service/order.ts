export class Order {
  _id: string;
     // buyer details
  name: String;
  email: String;
  shippingAddress: String;
    constructor() { 
    }
 }