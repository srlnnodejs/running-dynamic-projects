export class Item {
    _id: string;
    title: string;
    price: number;
    description: string;
    originalname: string;
    qty:number;

    constructor() { 
    }
 }