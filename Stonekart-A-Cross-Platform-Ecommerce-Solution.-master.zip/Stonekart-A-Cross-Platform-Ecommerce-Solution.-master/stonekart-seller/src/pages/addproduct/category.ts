export class Category {
            public _id:string;
            public name: string;
            public slug: number;
            public children: TemplateStringsArray;

            constructor() { 
            }
    
    }