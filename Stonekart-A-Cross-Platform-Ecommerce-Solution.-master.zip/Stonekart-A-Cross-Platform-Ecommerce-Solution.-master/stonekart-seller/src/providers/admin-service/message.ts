
export class  Message {
    _id: string;
    username: string;
    email: string;
    message : string;

    constructor() { 
    }
 }