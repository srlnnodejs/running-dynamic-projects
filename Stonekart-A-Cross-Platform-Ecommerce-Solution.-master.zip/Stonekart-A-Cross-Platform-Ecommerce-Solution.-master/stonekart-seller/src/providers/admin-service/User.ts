export class User {
    _id: string;
    firstname: string;
    lastname: number;
    email: string;
    mobilenumber : string;
    verified : boolean ;

    constructor() { 
    }
 }