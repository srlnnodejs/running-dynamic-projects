export class Seller {
    _id: string;
    firstname: string;
    lastname: number;
    email: string;
    mobilenumber : string;
    verified : boolean ;

    constructor() { 
    }
 }