# PAYTM PAYMENT APP
![Paytm](https://upload.wikimedia.org/wikipedia/commons/4/42/Paytm_logo.png)

**LIVE URL** https://paytm-pay.herokuapp.com/

## Installation
```
1. npm install
2. configure mid and merchant key in the /config/confif.js file
3. npm start
```
