const app = require("./app");

app.listen(3001, ()=>{
    console.log("server running!");
});