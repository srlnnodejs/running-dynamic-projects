# paytm-nodejs
paytm nodejs backend integration

Usage:
- Download the files
- Run npm init
- Run npm install --save express ejs cors consolidate body-parser
- Run nodemon server (Your server will start at port 3001)
- Goto url- http://localhost:3001/api/paytm/request
- Change the order id before performing a new transaction
- Test credentials for payment -> Phone no. 77777 77777, Otp 489871 (Find more test credentials at https://developer.paytm.com/docs/testing-integration)
