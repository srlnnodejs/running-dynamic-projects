import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accueil-general',
  templateUrl: './accueil-general.component.html',
  styleUrls: ['./accueil-general.component.css']
})
export class AccueilGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
