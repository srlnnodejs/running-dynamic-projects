angular.module('myApp',
	 ['ngCookies', 'ngResource', 'ngMessages', 'ngRoute', 'mgcrea.ngStrap'])
	.config( ['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider ){

	$locationProvider.html5Mode(true);

	$routeProvider
		.when('/', {
			templateUrl: 'views/home.html',
			controller: 'MainCtrl'
		})
		.when('/shows/:id', {
			templateUrl: 'views/detail.html',
			controller: 'DetailCtrl'
		})
		.when('/signup', {
			templateUrl: 'views/signup.html',
			controller: 'SignupCtrl'
		})
		.when('/login', {
			templateUrl: 'views/login.html',
			controller: 'LoginCtrl'
		})
		.when('/add', {
			templateUrl: 'views/add.html',
			controller: 'AddCtrl'
		})
		.otherwise({
			redirectTo : '/'
		});
		
}]);