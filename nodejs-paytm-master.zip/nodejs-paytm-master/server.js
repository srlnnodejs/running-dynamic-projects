const app = require("./app.js");

app.listen(3001, () => {
    console.log("Server bhaag raha hai!");
});
