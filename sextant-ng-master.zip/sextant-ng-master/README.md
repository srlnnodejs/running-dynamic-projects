Sextant
=======

###Microanalytics for a JavaScript world

Sextant is a minimal set of tracking metrics for web apps running on AngularJS. Getting started is simple: register an account at [sextant.io](http://sextant.io), specify the domain you&rsquo;d like to track (including the `http(s)://`), and copy the tracking script into the &lt;head&gt; of your app. Then make sure it&rsquo;s working: fire up your app, click around, and take a look at your dashboard!