module.exports = {
    dev:{
        options: {
            // execute a command
            command: 'reinstall',
            //optional: always get from HEAD
            latest: true,
            config: 'tsd.json'
        }
    }
};